//text to speech by horizon with auto spelling and autosuggest
// contact(KanzuWakazaki(facebook.com/Lazic.Kanzu)) for beta tester 🙉

module.exports = function (defaultFuncs, api, ctx) {
    return function unfriend(userID, callback) {

    }
}