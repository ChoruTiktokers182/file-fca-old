//keywords to Image by horizon with google rtc and A.I
// contact(KanzuWakazaki(facebook.com/Lazic.Kanzu)) for beta tester 🙉

module.exports = function (defaultFuncs, api, ctx) {
    return function unfriend(userID, callback) {

    }
}